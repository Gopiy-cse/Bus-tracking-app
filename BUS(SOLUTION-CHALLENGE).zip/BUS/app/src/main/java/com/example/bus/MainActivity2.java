package com.example.bus;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.common.util.concurrent.Service;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttSecurityException;
import org.eclipse.paho.client.mqttv3.internal.wire.MqttUnsubAck;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;


public class MainActivity2 extends AppCompatActivity  {


     MqttAndroidClient client;
    TextView subText;
    String topic,msg;


    @SuppressLint("MissingInflatedId")
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        subText=findViewById(R.id.subText);
        String clientId = MqttClient.generateClientId();

        client = new MqttAndroidClient(this.getApplicationContext(), "tcp://broker.hivemq.com:1883",clientId);


        topic=getIntent().getExtras().getString("id")+"/"+getIntent().getExtras().getString("name");
        String subs_top = ((MyApplication) this.getApplication()).getSomeVariable();
        try {
            IMqttToken token = client.connect();
            ((MyApplication) this.getApplication()).setClient(client);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                 //   Toast.makeText(MainActivity2.this,"connected!!",Toast.LENGTH_LONG).show();

                    Log.d("prev",subs_top);
                    setSubscription();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(MainActivity2.this,"connection failed!!",Toast.LENGTH_LONG).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                msg=new String(message.getPayload());
                Intent i = new Intent("location_update");
                i.putExtra("coord", msg);
                sendBroadcast(i);
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });


    }





    private void setSubscription(){
        try{
            client.subscribe(topic,1);
            //   Toast.makeText(MainActivity2.this,"subscribed:"+topic,Toast.LENGTH_SHORT).show();
            Log.d("current",topic);
            Intent i=new Intent(MainActivity2.this,MapsActivity.class);
            i.putExtra("topic",topic);

            startActivity(i);
            finish();
        }catch (MqttException e){
            e.printStackTrace();
        }
    }





}