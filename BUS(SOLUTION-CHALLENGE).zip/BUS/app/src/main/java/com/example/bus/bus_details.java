package com.example.bus;

import android.os.Bundle;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class bus_details extends AppCompatActivity {


    ListView fruitsList;
    String url;//"https://api.thingspeak.com/channels/2082044/feeds.json?api_key=B045RC72LQ0F8WRZ&results=1";
    //ProgressDialog dialog;

    FirebaseDatabase firebaseDatabase;

    // creating a variable for our
    // Database Reference for Firebase.
    DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_details);

        fruitsList = (ListView)findViewById(R.id.fruitsList);



        // variable for Text view.
        //private TextView retrieveTV;

            // below line is used to get the instance
            // of our Firebase database.
            firebaseDatabase = FirebaseDatabase.getInstance();

            // below line is used to get
            // reference for our database.
            databaseReference = firebaseDatabase.getReference("12");

            // initializing our object class variable.
            //retrieveTV = findViewById(R.id.idTVRetrieveData);

            // calling method
            // for getting data.
            getdata();
        try {
            TimeUnit.SECONDS.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Toast.makeText(this, "Before:"+url, Toast.LENGTH_SHORT).show();
        StringRequest request = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String string) {
                parseJsonData(string);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(getApplicationContext(), "Some error occurred!!", Toast.LENGTH_SHORT).show();
                //dialog.dismiss();
            }
        });

        RequestQueue rQueue = Volley.newRequestQueue(bus_details.this);
        rQueue.add(request);
        }

        private void getdata() {

            // calling add value event listener method
            // for getting the values from database.
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    // this method is call to get the realtime
                    // updates in the data.
                    // this method is called when the data is
                    // changed in our Firebase console.
                    // below line is for getting the data from
                    // snapshot of our database.
                    url = snapshot.getValue(String.class);
                    Toast.makeText(bus_details.this, url, Toast.LENGTH_SHORT).show();

                    // after getting the value we are setting
                    // our value to our text view in below line.
                    //retrieveTV.setText(value);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    // calling on cancelled method when we receive
                    // any error or we are not able to get the data.
                    Toast.makeText(bus_details.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
                }
            });
        }




            void parseJsonData(String jsonString) {
                try {
                    JSONObject object = new JSONObject(jsonString);
                    JSONArray fruitsArray = object.getJSONArray("feeds");
                    ArrayList al = new ArrayList();

                    for(int i = 0; i < fruitsArray.length(); ++i) {
                        al.add(fruitsArray.getString(i));
                    }

                    ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, al);
                    fruitsList.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

               // dialog.dismiss();
            }
        }
