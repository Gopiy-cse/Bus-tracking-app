package com.example.bus;

public class DataModel {


    private String name;
    private String id;
    //private String imgUrl;

    public DataModel() {
        // empty constructor required for firebase.
    }

    // constructor for our object class.
    public DataModel(String name,String id) {
        this.name = name;
        this.id=id;
        //this.imgUrl = imgUrl;
    }

    // getter and setter methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}

