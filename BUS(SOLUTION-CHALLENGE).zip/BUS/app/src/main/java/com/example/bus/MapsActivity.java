package com.example.bus;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.bus.databinding.ActivityMapsBinding;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttException;

import java.io.Serializable;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
    MqttAndroidClient b;
    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    double lat,lng;
    String topic;
    BroadcastReceiver broadcastReceiver = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
         topic=getIntent().getStringExtra("topic");
      /*  String latlng=getIntent().getStringExtra("coord");
        String[] latl=latlng.split(",",2);
        lat=Double.parseDouble(latl[0]);
        lng=Double.parseDouble(latl[1]);*/


    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
      //  boolean broadcastReceiver;


            broadcastReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                 //   Toast.makeText(context, "hello", Toast.LENGTH_SHORT).show();
mMap.clear();
                    String latlng=intent.getStringExtra("coord");
                    String[] latl=latlng.split(",",2);
                    lat=Double.parseDouble(latl[0]);
                    lng=Double.parseDouble(latl[1]);
Serializable a=intent.getExtras().getSerializable("obj");
                     b=(MqttAndroidClient)a;


                 MarkerOptions   place1 = new MarkerOptions().position(new LatLng(lat, lng)).title("Lahore");
                    mMap.addMarker(place1);
                   mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(lat, lng)));

                }
            };
        IntentFilter filter=new IntentFilter("location_update");
        this.registerReceiver(broadcastReceiver,filter);

      //  LatLng sydney = new LatLng(lat, lng);
    //    mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
     //   mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }

    @Override
    public void onBackPressed() {

        this.unregisterReceiver(broadcastReceiver);
        super.onBackPressed();
        MqttAndroidClient m=((MyApplication) this.getApplication()).getClient();
        try {
            m.unsubscribe(topic);
            m.disconnect();
       //     Toast.makeText(MapsActivity.this,"unsubscribed"+topic,Toast.LENGTH_SHORT).show();
        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
        finish();
    }
}
