package com.example.bus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    EditText UID,Passwd;
    Button login;

    private FirebaseAuth mauth;
    String mail,passwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mauth=FirebaseAuth.getInstance();
        

        UID=findViewById(R.id.reg);
        Passwd=findViewById(R.id.pass);
        login=findViewById(R.id.btn);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mail=UID.getText().toString();
                passwd=Passwd.getText().toString();

                if(TextUtils.isEmpty(mail)){
                    Toast.makeText(MainActivity.this, "Please Enter Mail", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(TextUtils.isEmpty(passwd)){
                    Toast.makeText(MainActivity.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(hasActiveInternetConnection(getApplicationContext())) {
                    mauth.signInWithEmailAndPassword(mail, passwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                                Intent i=new Intent(MainActivity.this,MainActivity3.class);
                                startActivity(i);
                            } else {
                                Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                                Intent i=new Intent(MainActivity.this,MainActivity3.class);
                            //   startActivity(i);
                            }
                        }
                    });
                }
                else{
                    Toast.makeText(MainActivity.this, "Please Enable Internet or WIFI", Toast.LENGTH_SHORT).show();
                }
            }
        });





    }


    public static boolean hasActiveInternetConnection (Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager != null)
        {
            NetworkInfo netInfos = connectivityManager.getActiveNetworkInfo();
            if(netInfos != null)
                if(netInfos.isConnected())
                    return true;
        }
        return false;
    }
}