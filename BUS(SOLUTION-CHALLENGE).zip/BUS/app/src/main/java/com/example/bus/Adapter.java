package com.example.bus;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.bus.DataModel;


import java.util.ArrayList;

public class Adapter extends ArrayAdapter<DataModel> {

    // constructor for our list view adapter.
    public Adapter(@NonNull Context context, ArrayList<DataModel> dataModelArrayList) {
        super(context, 0, dataModelArrayList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // below line is use to inflate the
        // layout for our item of list view.
        View listitemView = convertView;
        if (listitemView == null) {
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        // after inflating an item of listview item
        // we are getting data from array list inside
        // our modal class.
        DataModel dataModal = getItem(position);

        // initializing our UI components of list view item.
        TextView nameTV = listitemView.findViewById(R.id.idTVtext);
        //TextView courseIV = listitemView.findViewById(R.id.idTVtext1);

        // after initializing our items we are
        // setting data to our view.
        // below line is use to set data to our text view.
        nameTV.setText(dataModal.getName());

        //courseIV.setText(dataModal.getImgUrl());

        // in below line we are using Picasso to
        // load image from URL in our Image VIew.
        //Picasso.get().load(dataModal.getImgUrl()).into(courseIV);

        // below line is use to add item click listener
        // for our item of list view.
        listitemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // on the item click on our list view.
                // we are displaying a toast message.

                Intent i=new Intent(getContext(),MainActivity2.class);
                i.putExtra("name",dataModal.getName());
                i.putExtra("id",dataModal.getId());
                getContext().startActivity(i);
             //   Toast.makeText(getContext(), "Item clicked is : " + dataModal.getId(), Toast.LENGTH_SHORT).show();
            }
        });
        return listitemView;
    }
}
