package com.example.bus;

import android.app.Application;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.MqttClient;

public class MyApplication extends Application {

    private String var="notopic";
    String clientId = MqttClient.generateClientId();

    private MqttAndroidClient client;
    public String getSomeVariable() {
        return var;
    }

    public void setSomeVariable(String someVariable) {this.var = someVariable;}

    public  MqttAndroidClient getClient(){return client;}

    public void setClient(MqttAndroidClient cl){this.client=cl;}
}